Poker BreakSync
Developed by Seth Duncan

General Information:
Only one instance of the application should be running at a time. If multiple instances are running, data corruption may occur, and communication with the browser app over the network will break.

When the application is started, it will compare the provided date with a file containing daylight savings dates (daylight_savings.json). The dates listed extend to the end of 2027. If the date surpasses this range, the file needs updating by someone familiar with JSON format to ensure proper functionality.

Main Menu:

Start Break Sorter: Initiates the application. Opens a window to adjust the gaming date (defaulted to the current day) and calculates table break times.

Add Table: Opens a window to add tables by selecting a table number, game type (e.g., 2/5 NLH), date opened, and time opened. Tables can be added sequentially. Closing the window either adds or cancels table additions.

Close All Tables: Closes all open tables in the application. It's crucial to close all tables before generating a report when closing the room.

Generate Report and Close: Creates a PDF report of relevant events (table openings, closings, breaks), saves it to the designated folder in settings, and closes the application. Reports are named by the gaming day used during report generation.

Generate Report and Roll: Similar to 'Generate Report and Close' but keeps the application open, shifts the gaming day to the next day, and preserves table break information.

Quick Close: Closes the application while preserving its state. Upon reopening, all information and table logs are retained.

Full Close: Closes the application without preserving its state. Upon reopening, it starts as a new instance, with prior data lost.

Dashboard:

Main Display: Shows the gaming date, current time, and a list of tables scheduled for breaks within the next two hours.

Alerts: Displays alerts for tables overdue for breaks and for gaming day roll-overs that haven't occurred.

Table Break List: Lists tables and their scheduled breaks. A green circle indicates taken breaks, gray for those not taken. Breaks can be recorded remotely from the browser app.

Tables:

Open Table List: Displays currently open tables and a 'Focus' button for detailed table information and additional options.

Focused Table: Shows table number, game type, and provides options for recording breaks, closing the table, viewing logs, and managing upcoming breaks.

Network:

Event Log: Records communication between the application and the server, including errors and standard events. Refreshes every 5 minutes to check for remotely added breaks.

User List: Displays currently logged-in users to the browser app. Refresh button updates the list.

Status: Indicates server status; normally connected. Check logs for errors if disconnected.

Activation Code: Used for security to create user accounts. Set by clicking 'Set Activation Code' button. Incorrect codes prevent account creation.

Settings:

Configure settings such as the destination folder for reports, break times, maximum playing time, table and game configurations, network domain, and password changes.

Important: A full close is necessary before and after any setting changes to avoid conflicts.